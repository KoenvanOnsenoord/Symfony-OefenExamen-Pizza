<?php

namespace App\Entity;

use App\Repository\BestelregelRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: BestelregelRepository::class)]
class Bestelregel
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column]
    private ?int $aantal = null;



    #[ORM\ManyToOne(inversedBy: 'Bestelregel')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Pizza $getpizza = null;

    #[ORM\ManyToOne(inversedBy: 'bestelregel')]
    private ?Bestelling $bestelling = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getAantal(): ?int
    {
        return $this->aantal;
    }

    public function setAantal(int $aantal): self
    {
        $this->aantal = $aantal;

        return $this;
    }


    public function getGetpizza(): ?Pizza
    {
        return $this->getpizza;
    }

    public function setGetpizza(?Pizza $getpizza): self
    {
        $this->getpizza = $getpizza;

        return $this;
    }

    public function getBestelling(): ?Bestelling
    {
        return $this->bestelling;
    }

    public function setBestelling(?Bestelling $bestelling): self
    {
        $this->bestelling = $bestelling;

        return $this;
    }
}
